$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "12d459f3-c0b3-4767-8653-5abf0e81c0c8",
    "feature": "Search Functionality",
    "scenario": "Customer searching with a random string in amazon website",
    "start": 1636066791921,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1636066802408,
    "className": "passed"
  },
  {
    "id": "7e980100-2336-48f3-a7ec-8b7769efe04a",
    "feature": "Search Functionality",
    "scenario": "Customer searching for Mask in amazon website",
    "start": 1636066802417,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1636066814147,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});