package stepdefinitions;

import java.io.IOException;

import org.junit.Assert;

import com.pages.TestScriptPage;
import com.qa.factory.DriverFactory;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TestScriptSteps {

	private TestScriptPage testScriptPage = new TestScriptPage(DriverFactory.getDriver());
	
	
	@Given("I launch the amazon website")
	public void i_launch_the_amazon_website() throws InterruptedException {
		DriverFactory.getDriver().get("https://amazon.co.uk/");
		testScriptPage.acceptcookie();
		String ActualTitle = DriverFactory.getDriver().getTitle();
		String ExpectedTitle = "Amazon.co.uk: Low Prices in Electronics, Books, Sports Equipment & more";
		Assert.assertEquals(ExpectedTitle, ActualTitle);
		Thread.sleep(2000);
	}
	
	@When("I enter Mask in the search bar")
	public void i_enter_mask_in_the_search_bar() throws InterruptedException {
		testScriptPage.entertheitem();
		
	}
	
	@When("I enter random string in the search bar")
	public void i_enter_random_string_in_the_search_bar() throws InterruptedException {
		testScriptPage.randomstring();
	}
	
	
	@And("I click on search button")
	
	public void i_click_on_search_button() throws InterruptedException {
		testScriptPage.clickonsearch();
	}
	
	
	@Then("I should see only Mask products")
	public void i_should_see_only_mask_products() throws IOException {
		
		testScriptPage.productlist();
	}
	
	@Then("I should see the error page")
	public void i_should_see_the_error_page() throws IOException {
		testScriptPage.errorpage();
	
	}
	
}
	



	