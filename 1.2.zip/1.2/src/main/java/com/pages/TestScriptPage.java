package com.pages;


import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class TestScriptPage {

	private WebDriver driver;

	// 1. By Locators: OR
	
	private By acceptcookies = By.id("sp-cc-accept");
	private By searchbar = By.id("twotabsearchtextbox");
	private By searchbutton = By.id("nav-search-submit-button");
	private By products = By.xpath("//div[@class='s-matching-dir sg-col-16-of-20 sg-col sg-col-8-of-12 sg-col-12-of-16']");
	private By checkspelling = By.xpath("//span[.='Try checking your spelling or use more general terms']");
	
	
	
	// 2. Constructor of the page class:
		public TestScriptPage(WebDriver driver) {
			this.driver = driver;
		}
	
	
	// 3. Actions :
		public void acceptcookie()
		{
			driver.findElement(acceptcookies).click();
		}
		
		
		public void entertheitem()
		{
			driver.findElement(searchbar).sendKeys("Mask");
		}
		
		
		public void clickonsearch()
		{
			driver.findElement(searchbutton).click();
		}
		
		
		public void productlist() throws IOException
		{
			
			TakesScreenshot ts = (TakesScreenshot)driver;
			File file = ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(file, new File("./Screenshots/Mask.png"));
			String pdt = driver.findElement(products).getText();
			System.out.println("** THE PRODUCTS ARE ** = " + pdt);	
		}
		
		public void randomstring()
		{
			driver.findElement(searchbar).sendKeys("wertyuiopdfghjklcvbnmsdfghjkl");
		}
		
		
		public void errorpage() throws IOException
		{
			TakesScreenshot ts = (TakesScreenshot)driver;
			File file = ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(file, new File("./Screenshots/ErrorPage.png"));
			String title = driver.findElement(checkspelling).getText();
			System.out.println("** THE ERROR MESSAGE is ** = " + title);
		}
		
		
		
}
